<?php

class User {
    public $guid;
    public $username;
}

?>